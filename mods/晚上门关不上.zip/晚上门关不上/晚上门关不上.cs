using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace 晚上门关不上
{
    public class 晚上门关不上 : Mod
    {
    }

    public class DoorOpenerSystem : ModSystem
    {
        private int updateCounter;

        public override void PostUpdateEverything()
        {
            if (!Main.dayTime)
            {
                updateCounter++;
                if (updateCounter >= 30)
                {
                    updateCounter = 0;

                    int startX = (int)(Main.screenPosition.X / 16) - 5;
                    int endX = (int)((Main.screenPosition.X + Main.screenWidth) / 16) + 5;
                    int startY = (int)(Main.screenPosition.Y / 16) - 5;
                    int endY = (int)((Main.screenPosition.Y + Main.screenHeight) / 16) + 5;

                    for (int x = Math.Max(0, startX); x < Math.Min(Main.maxTilesX, endX); x++)
                    {
                        for (int y = Math.Max(0, startY); y < Math.Min(Main.maxTilesY, endY); y++)
                        {
                            Tile tile = Main.tile[x, y];
                            if (tile != null && tile is
                                    { HasTile: true, TileType: TileID.ClosedDoor or TileID.TallGateClosed })
                            {
                                WorldGen.OpenDoor(x, y, 0);
                                NetMessage.SendData(MessageID.ToggleDoorState, -1, -1, null, 0, x, y);
                            }
                        }
                    }
                }
            }
            else
            {
                updateCounter = 0;
            }
        }
    }
}